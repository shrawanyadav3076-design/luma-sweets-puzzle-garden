/**
 * LUMA SWEETS: PUZZLE GARDEN
 * 30 Individually Configured Starter Levels
 * Features diverse objectives: Target Score, Jelly Frost Clearing, Candy Collection, Chocolate Smash
 */

const LEVELS_DATA = [
  {
    id: 1,
    title: "Sweet Beginning",
    subtitle: "Welcome to the Puzzle Garden!",
    description: "Match 3 or more sweet candies to reach the target score.",
    objectiveType: "score",
    targetScore: 1200,
    moves: 18,
    stars: [1200, 2200, 3500],
    difficulty: "Easy",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon"]
  },
  {
    id: 2,
    title: "Berry Harvest",
    subtitle: "Pluck the ripest gummies",
    description: "Collect 16 Berry Drops before moves run out!",
    objectiveType: "collect",
    collectTargets: { berry: 16 },
    targetScore: 1500,
    moves: 18,
    stars: [1500, 2600, 4000],
    difficulty: "Easy",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon"]
  },
  {
    id: 3,
    title: "Frosted Sugar",
    subtitle: "Clear the sparkling jelly tiles",
    description: "Clear all 12 Frosted Jelly tiles under the candies.",
    objectiveType: "jelly",
    jellies: [
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 },
      { r: 3, c: 2 }, { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 3, c: 5 },
      { r: 4, c: 2 }, { r: 4, c: 3 }, { r: 4, c: 4 }, { r: 4, c: 5 }
    ],
    targetScore: 2000,
    moves: 20,
    stars: [2000, 3500, 5000],
    difficulty: "Easy",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 4,
    title: "Minty Meadow",
    subtitle: "Fresh herbal gems",
    description: "Collect 20 Mint Diamonds and reach 2,500 points.",
    objectiveType: "collect",
    collectTargets: { mint: 20 },
    targetScore: 2500,
    moves: 20,
    stars: [2500, 4000, 6000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 5,
    title: "Choco Wall",
    subtitle: "Break through sweet cocoa bricks",
    description: "Match next to the Chocolate Bricks to break all 8 of them!",
    objectiveType: "chocolate",
    chocolates: [
      { r: 3, c: 2 }, { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 3, c: 5 },
      { r: 4, c: 2 }, { r: 4, c: 3 }, { r: 4, c: 4 }, { r: 4, c: 5 }
    ],
    targetScore: 3000,
    moves: 22,
    stars: [3000, 4800, 7000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 6,
    title: "Starlight Garden",
    subtitle: "Make special striped candies",
    description: "Collect 18 Luma Stars and 18 Berry Drops.",
    objectiveType: "collect",
    collectTargets: { star: 18, berry: 18 },
    targetScore: 3500,
    moves: 22,
    stars: [3500, 5500, 8000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 7,
    title: "Frosty Corners",
    subtitle: "Garden paths coated in sugar",
    description: "Clear 16 Frosted Jelly tiles around the border.",
    objectiveType: "jelly",
    jellies: [
      { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 5 }, { r: 1, c: 6 },
      { r: 2, c: 1 }, { r: 2, c: 2 }, { r: 2, c: 5 }, { r: 2, c: 6 },
      { r: 5, c: 1 }, { r: 5, c: 2 }, { r: 5, c: 5 }, { r: 5, c: 6 },
      { r: 6, c: 1 }, { r: 6, c: 2 }, { r: 6, c: 5 }, { r: 6, c: 6 }
    ],
    targetScore: 4000,
    moves: 24,
    stars: [4000, 6200, 9000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 8,
    title: "Lemon Zest",
    subtitle: "High score fever",
    description: "Score 6,000 points using cascades and combos!",
    objectiveType: "score",
    targetScore: 6000,
    moves: 20,
    stars: [6000, 8500, 12000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 9,
    title: "Dual Pillars",
    subtitle: "Chocolate barricade",
    description: "Clear all 10 Chocolate Bricks blocking the garden flow.",
    objectiveType: "chocolate",
    chocolates: [
      { r: 1, c: 2 }, { r: 2, c: 2 }, { r: 3, c: 2 }, { r: 4, c: 2 }, { r: 5, c: 2 },
      { r: 1, c: 5 }, { r: 2, c: 5 }, { r: 3, c: 5 }, { r: 4, c: 5 }, { r: 5, c: 5 }
    ],
    targetScore: 4500,
    moves: 25,
    stars: [4500, 7000, 10000],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 10,
    title: "Sweet Blossom Grove",
    subtitle: "Chapter 1 Grand Finale!",
    description: "Clear 16 Jellies and collect 20 Azure Crystals!",
    objectiveType: "hybrid",
    collectTargets: { azure: 20 },
    jellies: [
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 },
      { r: 3, c: 2 }, { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 3, c: 5 },
      { r: 4, c: 2 }, { r: 4, c: 3 }, { r: 4, c: 4 }, { r: 4, c: 5 },
      { r: 5, c: 2 }, { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 5, c: 5 }
    ],
    targetScore: 5500,
    moves: 26,
    stars: [5500, 8500, 12500],
    difficulty: "Milestone",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },

  // Levels 11 - 20 (Chapter 2: Luminous Orchard)
  {
    id: 11,
    title: "Grape Canopy",
    subtitle: "Swirling purple harvest",
    description: "Collect 25 Grape Swirls and 15 Mint Diamonds.",
    objectiveType: "collect",
    collectTargets: { grape: 25, mint: 15 },
    targetScore: 5000,
    moves: 22,
    stars: [5000, 7500, 11000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 12,
    title: "Center Cross",
    subtitle: "Cross-shaped frost garden",
    description: "Clear 14 Jelly tiles in the center cross.",
    objectiveType: "jelly",
    jellies: [
      { r: 0, c: 3 }, { r: 1, c: 3 }, { r: 2, c: 3 }, { r: 3, c: 3 }, { r: 4, c: 3 }, { r: 5, c: 3 }, { r: 6, c: 3 }, { r: 7, c: 3 },
      { r: 3, c: 0 }, { r: 3, c: 1 }, { r: 3, c: 2 }, { r: 3, c: 4 }, { r: 3, c: 5 }, { r: 3, c: 6 }
    ],
    targetScore: 5200,
    moves: 24,
    stars: [5200, 8000, 11500],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "azure"]
  },
  {
    id: 13,
    title: "Chocolate Moat",
    subtitle: "Surrounded by rich fudge",
    description: "Smash all 12 Chocolate Bricks forming the perimeter moat.",
    objectiveType: "chocolate",
    chocolates: [
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 },
      { r: 5, c: 2 }, { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 5, c: 5 },
      { r: 3, c: 2 }, { r: 4, c: 2 }, { r: 3, c: 5 }, { r: 4, c: 5 }
    ],
    targetScore: 6000,
    moves: 25,
    stars: [6000, 9000, 13000],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 14,
    title: "Rainbow Spark",
    subtitle: "Prismatic power",
    description: "Score 8,000 points and create special combo reactions!",
    objectiveType: "score",
    targetScore: 8000,
    moves: 22,
    stars: [8000, 11000, 15000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 15,
    title: "Sugar Quilt",
    subtitle: "Checkerboard pattern of sweetness",
    description: "Clear 16 Frosted Jelly tiles in a checkerboard pattern.",
    objectiveType: "jelly",
    jellies: [
      { r: 1, c: 1 }, { r: 1, c: 3 }, { r: 1, c: 5 }, { r: 1, c: 7 },
      { r: 3, c: 0 }, { r: 3, c: 2 }, { r: 3, c: 4 }, { r: 3, c: 6 },
      { r: 5, c: 1 }, { r: 5, c: 3 }, { r: 5, c: 5 }, { r: 5, c: 7 },
      { r: 7, c: 0 }, { r: 7, c: 2 }, { r: 7, c: 4 }, { r: 7, c: 6 }
    ],
    targetScore: 6500,
    moves: 25,
    stars: [6500, 9500, 13500],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "azure"]
  },
  {
    id: 16,
    title: "Starry Night",
    subtitle: "Collect the radiant stars",
    description: "Collect 28 Luma Stars and 20 Lemon Bonbons.",
    objectiveType: "collect",
    collectTargets: { star: 28, lemon: 20 },
    targetScore: 7000,
    moves: 24,
    stars: [7000, 10000, 14000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "azure"]
  },
  {
    id: 17,
    title: "Choco Chevron",
    subtitle: "Diagonal chocolate wedges",
    description: "Destroy 10 Chocolate Bricks and score 7,500 points.",
    objectiveType: "chocolate",
    chocolates: [
      { r: 1, c: 1 }, { r: 2, c: 2 }, { r: 3, c: 3 }, { r: 4, c: 4 }, { r: 5, c: 5 },
      { r: 1, c: 6 }, { r: 2, c: 5 }, { r: 3, c: 4 }, { r: 4, c: 3 }, { r: 5, c: 2 }
    ],
    targetScore: 7500,
    moves: 26,
    stars: [7500, 10500, 14500],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 18,
    title: "Emerald Glade",
    subtitle: "Glade of minty gems",
    description: "Clear 18 Frosted Jelly tiles across the middle glade.",
    objectiveType: "jelly",
    jellies: [
      { r: 2, c: 1 }, { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 }, { r: 2, c: 6 },
      { r: 3, c: 1 }, { r: 3, c: 2 }, { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 3, c: 5 }, { r: 3, c: 6 },
      { r: 4, c: 1 }, { r: 4, c: 2 }, { r: 4, c: 3 }, { r: 4, c: 4 }, { r: 4, c: 5 }, { r: 4, c: 6 }
    ],
    targetScore: 8000,
    moves: 25,
    stars: [8000, 11500, 15500],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 19,
    title: "Berry Rush",
    subtitle: "Frenzied candy picking",
    description: "Collect 30 Berry Drops and 25 Azure Crystals.",
    objectiveType: "collect",
    collectTargets: { berry: 30, azure: 25 },
    targetScore: 8500,
    moves: 26,
    stars: [8500, 12000, 16000],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "grape", "azure"]
  },
  {
    id: 20,
    title: "Crystal Citadel",
    subtitle: "Chapter 2 Grand Milestone!",
    description: "Clear 20 Jellies and 8 Chocolate Bricks guarding the citadel!",
    objectiveType: "hybrid",
    chocolates: [
      { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 3, c: 2 }, { r: 3, c: 5 },
      { r: 4, c: 2 }, { r: 4, c: 5 }, { r: 5, c: 3 }, { r: 5, c: 4 }
    ],
    jellies: [
      { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 1, c: 4 }, { r: 1, c: 5 },
      { r: 6, c: 2 }, { r: 6, c: 3 }, { r: 6, c: 4 }, { r: 6, c: 5 },
      { r: 3, c: 1 }, { r: 4, c: 1 }, { r: 3, c: 6 }, { r: 4, c: 6 },
      { r: 2, c: 2 }, { r: 2, c: 5 }, { r: 5, c: 2 }, { r: 5, c: 5 },
      { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 4, c: 3 }, { r: 4, c: 4 }
    ],
    targetScore: 9500,
    moves: 28,
    stars: [9500, 13500, 18000],
    difficulty: "Milestone",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },

  // Levels 21 - 30 (Chapter 3: Royal Sugar Realm)
  {
    id: 21,
    title: "Glitter Cascades",
    subtitle: "Tumbling sweetness",
    description: "Score 10,000 points with massive cascading combos!",
    objectiveType: "score",
    targetScore: 10000,
    moves: 23,
    stars: [10000, 14000, 19000],
    difficulty: "Normal",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 22,
    title: "Diamond Ring",
    subtitle: "Loop of frosted sugar",
    description: "Clear 16 Jelly tiles forming an outer perimeter ring.",
    objectiveType: "jelly",
    jellies: [
      { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 1, c: 4 }, { r: 1, c: 5 }, { r: 1, c: 6 },
      { r: 6, c: 1 }, { r: 6, c: 2 }, { r: 6, c: 3 }, { r: 6, c: 4 }, { r: 6, c: 5 }, { r: 6, c: 6 },
      { r: 2, c: 1 }, { r: 3, c: 1 }, { r: 4, c: 1 }, { r: 5, c: 1 },
      { r: 2, c: 6 }, { r: 3, c: 6 }, { r: 4, c: 6 }, { r: 5, c: 6 }
    ],
    targetScore: 9000,
    moves: 26,
    stars: [9000, 13000, 17500],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 23,
    title: "Triple Chocolate Threat",
    subtitle: "Clustered cocoa boulders",
    description: "Smash 12 Chocolate Bricks clustered in three blocks.",
    objectiveType: "chocolate",
    chocolates: [
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 3, c: 2 }, { r: 3, c: 3 },
      { r: 2, c: 5 }, { r: 2, c: 6 }, { r: 3, c: 5 }, { r: 3, c: 6 },
      { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 6, c: 3 }, { r: 6, c: 4 }
    ],
    targetScore: 9500,
    moves: 27,
    stars: [9500, 13500, 18500],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "azure"]
  },
  {
    id: 24,
    title: "Golden Aura",
    subtitle: "Pure gold star collection",
    description: "Collect 35 Luma Stars and score 10,000 points.",
    objectiveType: "collect",
    collectTargets: { star: 35 },
    targetScore: 10000,
    moves: 25,
    stars: [10000, 14500, 19500],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "lemon", "grape", "azure"]
  },
  {
    id: 25,
    title: "Hourglass Frost",
    subtitle: "Sands of powdered sugar",
    description: "Clear 18 Jelly tiles in the hourglass pattern.",
    objectiveType: "jelly",
    jellies: [
      { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 1, c: 4 }, { r: 1, c: 5 }, { r: 1, c: 6 },
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 },
      { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 4, c: 3 }, { r: 4, c: 4 },
      { r: 5, c: 2 }, { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 5, c: 5 },
      { r: 6, c: 1 }, { r: 6, c: 2 }, { r: 6, c: 3 }, { r: 6, c: 4 }, { r: 6, c: 5 }, { r: 6, c: 6 }
    ],
    targetScore: 11000,
    moves: 28,
    stars: [11000, 15500, 21000],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 26,
    title: "Prismatic Palace",
    subtitle: "Harvest of all jewels",
    description: "Collect 25 Mint, 25 Berry, and 25 Azure gems!",
    objectiveType: "collect",
    collectTargets: { mint: 25, berry: 25, azure: 25 },
    targetScore: 11500,
    moves: 28,
    stars: [11500, 16000, 22000],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["mint", "berry", "azure", "star", "lemon"]
  },
  {
    id: 27,
    title: "Fortress of Fudge",
    subtitle: "Heavily fortified garden",
    description: "Destroy 14 Chocolate Bricks in the central fortress.",
    objectiveType: "chocolate",
    chocolates: [
      { r: 1, c: 3 }, { r: 1, c: 4 },
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 },
      { r: 3, c: 2 }, { r: 3, c: 5 },
      { r: 4, c: 2 }, { r: 4, c: 5 },
      { r: 5, c: 2 }, { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 5, c: 5 }
    ],
    targetScore: 12000,
    moves: 29,
    stars: [12000, 17000, 23000],
    difficulty: "Hard",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape"]
  },
  {
    id: 28,
    title: "Full Frosting",
    subtitle: "A garden blanketed in frost",
    description: "Clear 24 Frosted Jelly tiles across the lower garden.",
    objectiveType: "jelly",
    jellies: [
      { r: 4, c: 0 }, { r: 4, c: 1 }, { r: 4, c: 2 }, { r: 4, c: 3 }, { r: 4, c: 4 }, { r: 4, c: 5 }, { r: 4, c: 6 }, { r: 4, c: 7 },
      { r: 5, c: 0 }, { r: 5, c: 1 }, { r: 5, c: 2 }, { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 5, c: 5 }, { r: 5, c: 6 }, { r: 5, c: 7 },
      { r: 6, c: 0 }, { r: 6, c: 1 }, { r: 6, c: 2 }, { r: 6, c: 3 }, { r: 6, c: 4 }, { r: 6, c: 5 }, { r: 6, c: 6 }, { r: 6, c: 7 }
    ],
    targetScore: 13000,
    moves: 30,
    stars: [13000, 18500, 25000],
    difficulty: "Master",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 29,
    title: "Twilight Melody",
    subtitle: "The song of stars",
    description: "Collect 35 Stars, clear 12 Jellies, and score 14,000 points!",
    objectiveType: "hybrid",
    collectTargets: { star: 35 },
    jellies: [
      { r: 2, c: 2 }, { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 2, c: 5 },
      { r: 3, c: 2 }, { r: 3, c: 5 }, { r: 4, c: 2 }, { r: 4, c: 5 },
      { r: 5, c: 2 }, { r: 5, c: 3 }, { r: 5, c: 4 }, { r: 5, c: 5 }
    ],
    targetScore: 14000,
    moves: 30,
    stars: [14000, 20000, 27000],
    difficulty: "Master",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  },
  {
    id: 30,
    title: "Luma Sovereign Crown",
    subtitle: "The Ultimate Royal Garden Pinnacle!",
    description: "Clear the Royal Cross of 16 Jellies & 8 Chocolates to win the Crown!",
    objectiveType: "hybrid",
    chocolates: [
      { r: 2, c: 2 }, { r: 2, c: 5 }, { r: 5, c: 2 }, { r: 5, c: 5 },
      { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 4, c: 3 }, { r: 4, c: 4 }
    ],
    jellies: [
      { r: 1, c: 3 }, { r: 1, c: 4 }, { r: 6, c: 3 }, { r: 6, c: 4 },
      { r: 3, c: 1 }, { r: 4, c: 1 }, { r: 3, c: 6 }, { r: 4, c: 6 },
      { r: 2, c: 3 }, { r: 2, c: 4 }, { r: 5, c: 3 }, { r: 5, c: 4 },
      { r: 3, c: 2 }, { r: 4, c: 2 }, { r: 3, c: 5 }, { r: 4, c: 5 }
    ],
    targetScore: 16000,
    moves: 32,
    stars: [16000, 23000, 30000],
    difficulty: "Master",
    cols: 8,
    rows: 8,
    candies: ["star", "berry", "mint", "lemon", "grape", "azure"]
  }
];

if (typeof module !== "undefined" && module.exports) {
  module.exports = LEVELS_DATA;
}
