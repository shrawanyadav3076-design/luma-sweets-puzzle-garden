/**
 * LUMA SWEETS: PUZZLE GARDEN
 * Interactive Level Map Navigation System
 */

const LevelMap = {
  renderMap(containerId = "level-map-container") {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = "";

    const unlocked = StorageManager.data.unlockedLevel || 1;
    const pathWrapper = document.createElement("div");
    pathWrapper.className = "map-path-wrapper";

    // Build 30 level nodes in an undulating garden path
    LEVELS_DATA.forEach((lvl, index) => {
      const isUnlocked = lvl.id <= unlocked;
      const isCurrent = lvl.id === unlocked;
      const stars = StorageManager.getLevelStars(lvl.id);
      const isMilestone = lvl.id % 10 === 0;

      const node = document.createElement("div");
      node.className = `level-node ${isUnlocked ? "unlocked" : "locked"} ${isCurrent ? "current" : ""} ${isMilestone ? "milestone" : ""}`;
      node.dataset.levelId = lvl.id;

      // Position in sinuous winding path
      const wave = Math.sin((index / 29) * Math.PI * 6); // 3 smooth waves
      const xOffsetPercent = 50 + wave * 32; // between 18% and 82%
      node.style.left = `${xOffsetPercent}%`;

      // Vertical position (Level 1 at bottom, Level 30 at top)
      const yPos = 2320 - (index * 78);
      node.style.top = `${yPos}px`;

      // Inner content
      let innerHTML = "";
      if (isMilestone) {
        innerHTML += `<div class="milestone-crown">👑</div>`;
      }

      innerHTML += `<div class="level-badge">${lvl.id}</div>`;

      if (isUnlocked) {
        innerHTML += `
          <div class="stars-row">
            <span class="star-icon ${stars >= 1 ? 'earned' : 'empty'}">★</span>
            <span class="star-icon ${stars >= 2 ? 'earned' : 'empty'}">★</span>
            <span class="star-icon ${stars >= 3 ? 'earned' : 'empty'}">★</span>
          </div>
        `;
      } else {
        innerHTML += `<div class="lock-icon">🔒</div>`;
      }

      node.innerHTML = innerHTML;

      // Click to preview & play
      node.addEventListener("click", () => {
        Sound.playButton();
        if (isUnlocked) {
          UI.showLevelPreviewModal(lvl.id);
        } else {
          UI.showToast(`Level ${lvl.id} is locked. Complete earlier levels to unlock!`);
        }
      });

      pathWrapper.appendChild(node);
    });

    container.appendChild(pathWrapper);

    // Scroll automatically into view of current level
    setTimeout(() => {
      const currentNode = container.querySelector(".level-node.current");
      if (currentNode) {
        currentNode.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }, 150);
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = LevelMap;
}
