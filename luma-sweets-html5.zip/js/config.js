/**
 * LUMA SWEETS: PUZZLE GARDEN
 * Game Configuration & Constants
 */

const CONFIG = {
  APP_NAME: "Luma Sweets: Puzzle Garden",
  VERSION: "1.0.0",
  AUTHOR: "Luma Sweets Studio",

  // Board Configuration
  BOARD: {
    DEFAULT_COLS: 8,
    DEFAULT_ROWS: 8,
    MIN_MATCH: 3,
    MAX_SWAP_DISTANCE: 1
  },

  // Candy Types & Aesthetics
  // Each candy has distinct color, shape, and symbol for visual appeal and accessibility
  CANDIES: [
    {
      id: "star",
      name: "Luma Star",
      color: "#FFD13B",
      accent: "#FFF3A8",
      darkColor: "#C69B00",
      icon: "★",
      label: "Star Candy"
    },
    {
      id: "berry",
      name: "Berry Drop",
      color: "#FF2E74",
      accent: "#FFA6C5",
      darkColor: "#B50E45",
      icon: "♥",
      label: "Berry Drop"
    },
    {
      id: "mint",
      name: "Mint Diamond",
      color: "#00E59B",
      accent: "#A6FFDE",
      darkColor: "#008F5D",
      icon: "◆",
      label: "Mint Diamond"
    },
    {
      id: "lemon",
      name: "Lemon Bonbon",
      color: "#FF9F1C",
      accent: "#FFD899",
      darkColor: "#B36500",
      icon: "●",
      label: "Lemon Bonbon"
    },
    {
      id: "grape",
      name: "Grape Swirl",
      color: "#A259FF",
      accent: "#DDB8FF",
      darkColor: "#611CB8",
      icon: "✿",
      label: "Grape Swirl"
    },
    {
      id: "azure",
      name: "Azure Crystal",
      color: "#00D2FF",
      accent: "#A6F2FF",
      darkColor: "#007EA7",
      icon: "▲",
      label: "Azure Crystal"
    }
  ],

  // Special Piece IDs
  SPECIAL: {
    STRIPED_H: "striped_h", // Row clear
    STRIPED_V: "striped_v", // Col clear
    WRAPPED: "wrapped",     // 3x3 blast
    COLOR_BOMB: "color_bomb" // Color clear
  },

  // Blocker Types
  BLOCKERS: {
    JELLY: "jelly",           // Under-candy frosted tile
    DOUBLE_JELLY: "jelly_2",   // 2-layer jelly
    CHOCOLATE: "chocolate",   // Choco brick
    COOKIE: "cookie"          // Sugar cookie barrier
  },

  // Scoring Rules
  SCORES: {
    MATCH_3: 60,
    MATCH_4: 120,
    MATCH_5: 250,
    WRAPPED_BLAST: 180,
    LINE_BLAST: 140,
    COLOR_BOMB: 300,
    JELLY_CLEAR: 100,
    CHOCO_CLEAR: 150,
    COMBO_BONUS: 50,
    REMAINING_MOVE_BONUS: 1000
  },

  // Praise Phrases for Combos
  PRAISES: [
    "SWEET!",
    "TASTY!",
    "DELICIOUS!",
    "DIVINE!",
    "SUGAR CRUSH!",
    "SENSATIONAL!",
    "LUMINOUS!"
  ],

  // Default Starting Inventory
  DEFAULT_INVENTORY: {
    coins: 300,
    boosters: {
      hammer: 3,
      shuffle: 3,
      rainbow: 2,
      moves: 2
    }
  },

  // Booster Costs & Descriptions
  BOOSTER_INFO: {
    hammer: {
      name: "Lollipop Hammer",
      description: "Smashes any single candy or blocker instantly!",
      cost: 120
    },
    shuffle: {
      name: "Sweet Shuffle",
      description: "Scrambles the entire board for new match opportunities!",
      cost: 90
    },
    rainbow: {
      name: "Rainbow Bomb",
      description: "Creates a powerful Color Bomb on any chosen candy!",
      cost: 160
    },
    moves: {
      name: "+5 Extra Moves",
      description: "Grants 5 extra moves to finish the puzzle!",
      cost: 100
    }
  },

  // Default Audio Settings
  AUDIO_DEFAULTS: {
    masterMute: false,
    musicEnabled: true,
    sfxEnabled: true,
    musicVolume: 0.65,
    sfxVolume: 0.85
  },

  // Animation Timings (in milliseconds)
  ANIMATION: {
    SWAP_DURATION: 200,
    MATCH_CLEAR: 250,
    DROP_GRAVITY: 240,
    SPECIAL_FX: 400
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = CONFIG;
}
